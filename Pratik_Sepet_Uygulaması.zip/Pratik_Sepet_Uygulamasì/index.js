
let product1 = { name: "Klavye", price: 1000, imagepath: "/IMAGES/Klavye.jpg" }

let product2 = { name: "Mouse", price: 900, imagepath: "/IMAGES/Mouse.jpg" }

let product3 = { name: "Laptop", price: 15000, imagepath: "/IMAGES/Laptop.jpg" }

let product4 = { name: "Kulaklık", price: 1200, imagepath: "/IMAGES/Kulaklık.webp" }

let product5 = { name: "Hoparlör", price: 500, imagepath: "/IMAGES/Hoparlör.jpg" }

let product6 = { name: "Monitör", price: 1200, imagepath: "/IMAGES/Monitör.webp" }

let products = [product1, product2, product3, product4, product5, product6];

const productContainer = document.getElementById('Product');

GetProducts();

function GetProducts(){
    const cardDeck = document.createElement('div');
    cardDeck.classList.add('card-deck');

    products.forEach(product => {
        const card = document.createElement('div');
        card.classList.add('card', 'm-4');
        card.innerHTML = `
            <div>
                <img
                    src="${product.imagepath}"
                    alt="product"
                    class="card-img-top img-fluid"
                />
                <div class="card-body">
                    <h2 class="card-title shadow-dark">${product.name}</h2>
                    <div class="d-flex justify-content-between">
                        <a class="btn btn-info text-white" href="#">Sepete Ekle</a>
                        <span class="price badge rounded-pill bg-warning text-dark d-flex align-items-center">${product.price}</span>
                    </div>
                </div>
            </div>
        `;
        cardDeck.appendChild(card);
    });

    productContainer.appendChild(cardDeck);
}



const card = document.getElementsByClassName("card");
const btnAdd = document.getElementsByClassName("btn-info");
const btnCart = document.querySelector(".btn-cart");
const cartList = document.querySelector(".shopping-cart-list");

class Shopping{
    constructor(title,price,image){
        this.image = image;
        this.title = title;
        this.price = price;
    }
}

class UI{

    addToCart(shopping){
        const listItem = document.createElement("div");
        listItem.classList = "list-item";

        listItem.innerHTML = 
        `
        <div class="row align-items-center text-white-50 border">
            <div class="col-md-3">
                <img src="${shopping.image}" alt="product" class="img-fluid">
            </div>
            <div class="col-md-5">
                <div class="title">${shopping.title}</div>
            </div>
            <div class="col-md-2">
                <div class="price">${shopping.price}</div>
            </div>
            <div class="col-md-2">
                <button class="btn btn-delete">
                    <i class="fas fa-trash-alt text-danger"></i>
                </button>
            </div>
        </div>
        `
        cartList.appendChild(listItem);
    }

    removeCart(){
        let btnRemove = document.getElementsByClassName("btn-delete");
        let self = this;
        for (let i = 0; i < btnRemove.length; i++) {
            btnRemove[i].addEventListener("click", function(){
                this.parentElement.parentElement.parentElement.remove();
                self.cartCount();
            })
            
        }
    }

    cartCount(){
        let cartListItem = cartList.getElementsByClassName("list-item");
        let itemCount = document.getElementById("item-count");
        itemCount.innerHTML = cartListItem.length;
    }

    cartToggle(){
        btnCart.addEventListener("click", function(){
            cartList.classList.toggle("d-none");
        })
    }
    
}


for (let i = 0; i < card.length; i++) {
    btnAdd[i].addEventListener("click", function(e){
        let title = card[i].getElementsByClassName("card-title")[0].textContent;
        let price = card[i].getElementsByClassName("price")[0].textContent;
        let image = card[i].getElementsByClassName("card-img-top")[0].src;
        btnAdd[i].classList.add("disabled");
        btnAdd[i].textContent = "Sepete Eklendi";
        let shopping = new Shopping(title,price,image);
        let ui = new UI();

        ui.addToCart(shopping);
        ui.removeCart()
        ui.cartCount();


        e.preventDefault();
    })
}

document.addEventListener("DOMContentLoaded", ()=> {
    let ui = new UI();

    ui.cartToggle();
})
const searchInput = document.getElementById('Search');
const searchButton = document.getElementById('SearchButton');

searchButton.addEventListener('click', searchProducts);

function searchProducts(e) {
    e.preventDefault();
    const searchTerm = searchInput.value.toLowerCase();
    const filteredProducts = products.filter(product => {
        return product.name.toLowerCase().includes(searchTerm);
    });
    displayFilteredProducts(filteredProducts);
}

function displayFilteredProducts(filteredProducts) {
    productContainer.innerHTML = '';
    const cardDeck = document.createElement('div');
    cardDeck.classList.add('card-deck');

    filteredProducts.forEach(product => {
        const card = document.createElement('div');
        card.classList.add('card', 'm-4');
        card.innerHTML = `
            <div>
                <img
                    src="${product.imagepath}"
                    alt="product"
                    class="card-img-top img-fluid"
                />
                <div class="card-body">
                    <h2 class="card-title shadow-dark">${product.name}</h2>
                    <div class="d-flex justify-content-between">
                        <a class="btn btn-info text-white" href="#">Sepete Ekle</a>
                        <span class="price badge rounded-pill bg-warning text-dark d-flex align-items-center">${product.price}</span>
                    </div>
                </div>
            </div>
        `;
        
        cardDeck.appendChild(card);
    });

    productContainer.appendChild(cardDeck);
}

